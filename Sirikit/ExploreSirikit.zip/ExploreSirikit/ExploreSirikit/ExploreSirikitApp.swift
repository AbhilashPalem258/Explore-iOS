//
//  ExploreSirikitApp.swift
//  ExploreSirikit
//
//  Created by Abhilash Palem on 28/09/22.
//

import SwiftUI

@main
struct ExploreSirikitApp: App {
    var body: some Scene {
        WindowGroup {
            BankAccountView()
        }
    }
}
